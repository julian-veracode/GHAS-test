package com.veracode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cweid73ApplicationTests {

    @Test
    void contextLoads() {
    }

}
